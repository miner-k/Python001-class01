from django.apps import AppConfig


class PhoneConfig(AppConfig):
    name = 'phone'
