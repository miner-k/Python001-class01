# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Pid0A8Dfa51F2(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_0a8dfa51f2'


class Pid15Fa029031(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_15fa029031'


class Pid16141F9C92(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_16141f9c92'


class Pid16F51F5370(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_16f51f5370'


class Pid1B3Ab3Fa7A(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_1b3ab3fa7a'


class Pid1E169A5Fe0(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_1e169a5fe0'


class Pid1F3Ffc4604(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_1f3ffc4604'


class Pid23793Be281(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_23793be281'


class Pid27581Fb84F(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_27581fb84f'


class Pid29Af119404(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_29af119404'


class Pid2Bff897D5A(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_2bff897d5a'


class Pid2E3468A6F4(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_2e3468a6f4'


class Pid2E5F7Beacb(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_2e5f7beacb'


class Pid2F30583D6E(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_2f30583d6e'


class Pid2F57942C23(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_2f57942c23'


class Pid3132342B77(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_3132342b77'


class Pid387C9E8599(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_387c9e8599'


class Pid39424Cfb8E(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_39424cfb8e'


class Pid3B4979525A(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_3b4979525a'


class Pid42B2C22A9E(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_42b2c22a9e'


class Pid46226A17A1(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_46226a17a1'


class Pid4Af605D15D(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_4af605d15d'


class Pid4Cc0E22De1(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_4cc0e22de1'


class Pid4D302C9Ad0(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_4d302c9ad0'


class Pid50880B3A3F(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_50880b3a3f'


class Pid56613055A2(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_56613055a2'


class Pid577C785B3E(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_577c785b3e'


class Pid5Ac8Fd0Cdd(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_5ac8fd0cdd'


class Pid5B2101608E(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_5b2101608e'


class Pid5B90Df0375(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_5b90df0375'


class Pid64288Cacb6(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_64288cacb6'


class Pid677899865A(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_677899865a'


class Pid68Dce6Dcbb(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_68dce6dcbb'


class Pid69D09Cbcf2(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_69d09cbcf2'


class Pid6B918Bd0E8(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_6b918bd0e8'


class Pid6Be9A29Ab4(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_6be9a29ab4'


class Pid6Cb47E16B4(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_6cb47e16b4'


class Pid7751295Dac(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_7751295dac'


class Pid78A2D87729(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_78a2d87729'


class Pid79412622Af(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_79412622af'


class Pid7Bf86137E4(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_7bf86137e4'


class Pid7C00271186(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_7c00271186'


class Pid7Cf7862E42(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_7cf7862e42'


class Pid7F3768021A(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_7f3768021a'


class Pid7F6Dda0476(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_7f6dda0476'


class Pid816B11Deac(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_816b11deac'


class Pid8428D87C18(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_8428d87c18'


class Pid84D5F74729(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_84d5f74729'


class Pid87A812B6D0(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_87a812b6d0'


class Pid8F332Caa60(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_8f332caa60'


class Pid906Befedb1(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_906befedb1'


class Pid908Fbb36Bb(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_908fbb36bb'


class Pid9221B9Ef85(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_9221b9ef85'


class Pid93Fb74Dbc0(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_93fb74dbc0'


class Pid9C0Cd2140F(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_9c0cd2140f'


class PidA33Ce38F2A(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_a33ce38f2a'


class PidB29Abe2C96(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_b29abe2c96'


class PidB4B8E07F7D(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_b4b8e07f7d'


class PidB4F130Cfeb(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_b4f130cfeb'


class PidBd772D0885(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_bd772d0885'


class PidC13Afd7F56(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_c13afd7f56'


class PidC37D741A86(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_c37d741a86'


class PidC466A069A3(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_c466a069a3'


class PidC54132B8E8(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_c54132b8e8'


class PidC6Bd8F5076(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_c6bd8f5076'


class PidC9540B5365(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_c9540b5365'


class PidCbadfe763F(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_cbadfe763f'


class PidD1D4153420(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_d1d4153420'


class PidD4E7Cdb9Cd(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_d4e7cdb9cd'


class PidD7C0Db709C(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_d7c0db709c'


class PidDf059F0B8B(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_df059f0b8b'


class PidE1721Db538(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_e1721db538'


class PidE2C37C1A85(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_e2c37c1a85'


class PidE63F898Acc(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_e63f898acc'


class PidE7Cd893Ecb(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_e7cd893ecb'


class PidE803867C36(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_e803867c36'


class PidE81Ff08947(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_e81ff08947'


class PidF565F009E1(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_f565f009e1'


class PidF59A3F1441(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_f59a3f1441'


class PidF5A9F0D89C(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_f5a9f0d89c'


class PidF60646175E(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_f60646175e'


class PidF70F28F98C(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_f70f28f98c'


class PidF81435Ca40(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_f81435ca40'


class PidF9Ccf73D3A(models.Model):
    comment_text = models.TextField(blank=True, null=True)
    emotional_value = models.FloatField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Pid_f9ccf73d3a'


class AuthGroup(models.Model):
    name = models.CharField(unique=True, max_length=150)

    class Meta:
        managed = False
        db_table = 'auth_group'


class AuthGroupPermissions(models.Model):
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)
    permission = models.ForeignKey('AuthPermission', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_group_permissions'
        unique_together = (('group', 'permission'),)


class AuthPermission(models.Model):
    name = models.CharField(max_length=255)
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING)
    codename = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'auth_permission'
        unique_together = (('content_type', 'codename'),)


class AuthUser(models.Model):
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.IntegerField()
    username = models.CharField(unique=True, max_length=150)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=150)
    email = models.CharField(max_length=254)
    is_staff = models.IntegerField()
    is_active = models.IntegerField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'


class AuthUserGroups(models.Model):
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_groups'
        unique_together = (('user', 'group'),)


class AuthUserUserPermissions(models.Model):
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    permission = models.ForeignKey(AuthPermission, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_user_permissions'
        unique_together = (('user', 'permission'),)


class Comment20200902(models.Model):
    datetime = models.DateTimeField()
    product_name = models.CharField(max_length=200)
    comment_count = models.CharField(max_length=10)
    product_id = models.CharField(max_length=11)
    comment_text = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'comment_2020_09_02'


class Comment20200903(models.Model):
    datetime = models.DateTimeField()
    product_name = models.CharField(max_length=200)
    comment_count = models.CharField(max_length=10)
    product_id = models.CharField(max_length=11)
    comment_text = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'comment_2020_09_03'


class Comment20200904(models.Model):
    datetime = models.DateTimeField()
    product_name = models.CharField(max_length=200)
    comment_count = models.CharField(max_length=10)
    product_id = models.CharField(max_length=11)
    comment_text = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'comment_2020_09_04'


class CommentAnalyzeHis(models.Model):
    index = models.BigIntegerField(blank=True, null=True)
    product_id = models.TextField(blank=True, null=True)
    soucre_table = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'comment_analyze_his'


class DjangoAdminLog(models.Model):
    action_time = models.DateTimeField()
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=200)
    action_flag = models.PositiveSmallIntegerField()
    change_message = models.TextField()
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING, blank=True, null=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=40)
    session_data = models.TextField()
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'
