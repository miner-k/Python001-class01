from django.contrib import admin
from django.urls import path,include
from . import views

urlpatterns = [
    path('', views.show_today),
    path('product/8F332Caa60', views.show_product),
]